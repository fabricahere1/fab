import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:firebase_auth/firebase_auth.dart';

import '../features/auth/presentation/login_screen.dart';
import '../features/auth/presentation/register_screen.dart';
import '../features/auth/presentation/profil_tamamla_screen.dart';
import '../features/home/presentation/home_screen.dart';
import '../features/ilanlar/domain/ilan_model.dart';
import '../features/ilanlar/presentation/ilan_detay_screen.dart';
import '../features/ilanlar/presentation/gelenler_screen.dart';
import '../features/ilanlar/presentation/favoriler_screen.dart';
import '../features/auth/providers/auth_provider.dart';
import '../features/profil/providers/profil_provider.dart';

part 'app_router.g.dart';

// ── Global navigator key — in-app banner için ─────────────
final navigatorKey = GlobalKey<NavigatorState>();

abstract class AppRoutes {
  static const splash        = '/';
  static const login         = '/login';
  static const register      = '/register';
  static const profilTamamla = '/profil-tamamla';
  static const home          = '/home';
  static const ilanDetay     = '/ilan/:ilanId';
  static const gelenler      = '/gelenler';
  static const favoriler     = '/favoriler';

  static String ilanDetayPath(String ilanId) => '/ilan/$ilanId';
  static String gelenlerPath({List<String> kategoriYolu = const [], String? tip}) {
    final params = <String>[];
    if (kategoriYolu.isNotEmpty) params.add('kategori=${kategoriYolu.join(',')}');
    if (tip != null && tip.isNotEmpty) params.add('tip=$tip');
    if (params.isEmpty) return gelenler;
    return '$gelenler?${params.join('&')}';
  }
}

class _AppStateNotifier extends ChangeNotifier {
  _AppStateNotifier(this._ref) {
    _authSub   = _ref.listen(authStateProvider, (_, _) => notifyListeners());
    _profilSub = _ref.listen(benimKullaniciProfilProvider, (_, _) => notifyListeners());
  }

  final Ref _ref;
  late final ProviderSubscription _authSub;
  late final ProviderSubscription _profilSub;

  @override
  void dispose() {
    _authSub.close();
    _profilSub.close();
    super.dispose();
  }
}

@Riverpod(keepAlive: true)
GoRouter router(Ref ref) {
  final notifier = _AppStateNotifier(ref);
  ref.onDispose(notifier.dispose);

  return GoRouter(
    navigatorKey: navigatorKey,
    initialLocation: AppRoutes.splash,
    refreshListenable: notifier,
    redirect: (context, state) {
      final authAsync = ref.read(authStateProvider);
      final loc = state.matchedLocation;

      // Firebase Auth henüz ilk cevabını vermedi (yerel disk cache'i
      // okunuyor) — bu sırada login'e ATLAMA, splash'ta kal. Cevap
      // gelince _AppStateNotifier zaten notifyListeners() çağırıp
      // router'ı yeniden değerlendirtecek.
      if (authAsync.isLoading && !authAsync.hasValue) {
        return loc == AppRoutes.splash ? null : AppRoutes.splash;
      }

      final user = authAsync.value;
      final girisYapildi = user != null;

      if (loc.startsWith('/ilan/')) {
        if (!girisYapildi) {
          return '${AppRoutes.login}?redirect=${state.uri}';
        }
        return null;
      }

      if (!girisYapildi) {
        if (loc == AppRoutes.login || loc == AppRoutes.register) return null;
        return AppRoutes.login;
      }

      if (loc == AppRoutes.splash ||
          loc == AppRoutes.login  ||
          loc == AppRoutes.register) {
        return _hedefBelirle(ref, user);
      }

      if (loc == AppRoutes.profilTamamla) {
        final profil = ref.read(benimKullaniciProfilProvider).value;
        if (profil?.profilTamamlandi == true) return AppRoutes.home;
        return null;
      }

      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        builder: (_, _) => const _SplashPage(),
      ),
      GoRoute(
        path: AppRoutes.login,
        builder: (_, _) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (_, _) => const RegisterScreen(),
      ),
      GoRoute(
        path: AppRoutes.profilTamamla,
        builder: (_, _) => const ProfilTamamlaScreen(ilkGiris: true),
      ),
      GoRoute(
        path: AppRoutes.home,
        builder: (_, _) => const HomeScreen(),
      ),
      GoRoute(
        path: AppRoutes.ilanDetay,
        builder: (_, state) {
          final ilanId = state.pathParameters['ilanId']!;
          final ilan = state.extra as IlanModel?;
          return IlanDetayScreen(ilanId: ilanId, ilan: ilan);
        },
      ), // GoRoute
      GoRoute(
        path: AppRoutes.favoriler,
        builder: (_, _) => const FavorilerScreen(),
      ),
      GoRoute(
        path: AppRoutes.gelenler,
        builder: (_, state) {
          final kategoriParam = state.uri.queryParameters['kategori'] ?? '';
          final kategoriYolu = kategoriParam.isNotEmpty
              ? kategoriParam.split(',')
              : <String>[];
          final tip = state.uri.queryParameters['tip'];
          return GelenlerDetayScreen(kategoriYolu: kategoriYolu, tip: tip);
        },
      ),
    ],
  );
}

String? _hedefBelirle(Ref ref, User user) {
  final profilAsync = ref.read(benimKullaniciProfilProvider);
  // Profil henüz yüklenmediyse bekle — router profil gelince tekrar tetiklenecek
  if (profilAsync.isLoading) return null;

  final emailKullanicisi =
      user.providerData.any((p) => p.providerId == 'password');
  final googleKullanicisi =
      user.providerData.any((p) => p.providerId == 'google.com');
  final telefonKullanicisi =
      user.providerData.any((p) => p.providerId == 'phone');

  // Sadece email/password kullananlar profil tamamlama adımını atlar
  if (emailKullanicisi && !googleKullanicisi && !telefonKullanicisi) {
    return AppRoutes.home;
  }

  final tamamlandi = profilAsync.value?.profilTamamlandi ?? false;
  return tamamlandi ? AppRoutes.home : AppRoutes.profilTamamla;
}

class _SplashPage extends StatefulWidget {
  const _SplashPage();

  @override
  State<_SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<_SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _logoOpacity;
  late final Animation<double> _logoScale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _logoOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.6, curve: Curves.easeOut)),
    );
    _logoScale = Tween<double>(begin: 0.75, end: 1).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.7, curve: Curves.easeOutBack)),
    );

    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Gerçek native splash rengi (android/.../styles.xml: #E53935) ile
      // birebir aynı zemin — Android'in sistem splash ikonu, Flutter'ın ilk
      // karesi çizildikten sonra ÜZERİNE bindirilip çıkış animasyonu yapıyor;
      // altındaki bu zemin uyuşmazsa "siyah ekran" hissi oluşuyordu.
      backgroundColor: const Color(0xFFE53935),
      body: Center(
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, _) => Opacity(
            opacity: _logoOpacity.value,
            child: Transform.scale(
              scale: _logoScale.value,
              // Native splash'taki aynı görsel — pürüzsüz, kesintisiz geçiş.
              child: Image.asset(
                'assets/splash/iste_splash.png',
                fit: BoxFit.contain,
              ),
            ),
          ),
        ),
      ),
    );
  }
}