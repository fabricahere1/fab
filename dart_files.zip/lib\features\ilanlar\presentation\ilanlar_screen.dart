// lib/features/ilanlar/presentation/ilanlar_screen.dart
//
// Değişiklikler (eskiye göre):
//   • GoruntulemeModeli.liste kaldırıldı → swipe eklendi
//   • Mod butonu: tek buton döngü → 3 ayrı küçük ikonlu buton (sağ üst köşe)
//   • Arama çubuğu: yuvarlak pill → köşeli, daha belirgin border, kırmızı filtre butonu
//   • Swipe modunda liste/grid yerine SwipeGorunumu gösteriliyor
//   • Swipe modunda FAB gizleniyor (alt butonlar var)
//   • Neden İSTE barı korundu

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:google_fonts/google_fonts.dart';
import '../domain/ilan_model.dart';
import '../providers/ilan_provider.dart';
import '../providers/grid_tercihi_notifier.dart';
import '../presentation/ilan_form_screen.dart';
import '../../../shared/constants/app_colors.dart';
import '../../../shared/constants/app_constants.dart';
import '../../../shared/widgets/bildirim_cani_widget.dart';
import 'widgets/filtre_ekrani.dart';
import 'widgets/ilan_karti.dart';
import 'widgets/swipe_karti.dart';

const _kResimYukseklikleri = [120.0, 150.0, 105.0, 135.0, 165.0, 112.0];

enum SiralamaTipi { enYeni, enEski, ucretArtan, ucretAzalan }

extension SiralamaTipiX on SiralamaTipi {
  String get label {
    switch (this) {
      case SiralamaTipi.enYeni:      return 'En yeni';
      case SiralamaTipi.enEski:      return 'En eski';
      case SiralamaTipi.ucretArtan:  return 'Ücret: Düşük → Yüksek';
      case SiralamaTipi.ucretAzalan: return 'Ücret: Yüksek → Düşük';
    }
  }
}

class IsteklerIcEkran extends ConsumerStatefulWidget {
  const IsteklerIcEkran({super.key});

  @override
  ConsumerState<IsteklerIcEkran> createState() => _IsteklerIcEkranState();
}

class _IsteklerIcEkranState extends ConsumerState<IsteklerIcEkran>
    with AutomaticKeepAliveClientMixin {
  final _scrollController   = ScrollController();
  final _aramaCtrl          = TextEditingController();
  final _kategoriScrollCtrl = ScrollController();

  SiralamaTipi _siralama   = SiralamaTipi.enYeni;
  String?      _seciliAnaKey;
  String?      _seciliAltKey;
  String       _aramaMetni = '';
  bool         _aramaGizli = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    final pos = _scrollController.position;
    if (pos.userScrollDirection == ScrollDirection.reverse && !_aramaGizli) {
      setState(() => _aramaGizli = true);
    } else if (pos.userScrollDirection == ScrollDirection.forward && _aramaGizli) {
      setState(() => _aramaGizli = false);
    }
    if (pos.pixels >= pos.maxScrollExtent - 120) {
      if (!ref.read(istekIlanlarProvider).yukleniyor) {
        ref.read(istekIlanlarProvider.notifier).dahaFazlaYukle();
      }
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _aramaCtrl.dispose();
    _kategoriScrollCtrl.dispose();
    super.dispose();
  }

  String get _filtreBadgeMetni {
    if (_seciliAnaKey == null) return '';
    final ana = kKategoriAgaci.firstWhere(
      (k) => k.key == _seciliAnaKey,
      orElse: () => AnaKategori(key: '', ad: '', emoji: ''),
    );
    if (_seciliAltKey != null) {
      final alt = ana.altlar.firstWhere(
        (a) => a.key == _seciliAltKey,
        orElse: () => AltKategori(key: '', ad: ''),
      );
      if (alt.key.isNotEmpty) return alt.ad;
    }
    return ana.ad;
  }

  List<IlanModel> _sirala(List<IlanModel> liste) {
    final kopya = List<IlanModel>.from(liste);
    switch (_siralama) {
      case SiralamaTipi.enYeni:
        kopya.sort((a, b) => (b.olusturmaTarihi ?? DateTime(0))
            .compareTo(a.olusturmaTarihi ?? DateTime(0)));
      case SiralamaTipi.enEski:
        kopya.sort((a, b) => (a.olusturmaTarihi ?? DateTime(0))
            .compareTo(b.olusturmaTarihi ?? DateTime(0)));
      case SiralamaTipi.ucretArtan:
        kopya.sort((a, b) {
          final aU = double.tryParse(a.ucret) ?? 0;
          final bU = double.tryParse(b.ucret) ?? 0;
          return aU.compareTo(bU);
        });
      case SiralamaTipi.ucretAzalan:
        kopya.sort((a, b) {
          final aU = double.tryParse(a.ucret) ?? 0;
          final bU = double.tryParse(b.ucret) ?? 0;
          return bU.compareTo(aU);
        });
    }
    return kopya;
  }

  List<IlanModel> _filtrele(List<IlanModel> liste) {
    var sonuc = liste;
    if (_seciliAltKey != null) {
      sonuc = sonuc.where((i) => i.kategori == _seciliAltKey).toList();
    } else if (_seciliAnaKey != null) {
      final anaKat = kKategoriAgaci.firstWhere(
        (k) => k.key == _seciliAnaKey,
        orElse: () => AnaKategori(key: '', ad: '', emoji: ''),
      );
      if (anaKat.altlar.isNotEmpty) {
        final gecerliKeyler = {anaKat.key, ...anaKat.altlar.map((a) => a.key)};
        sonuc = sonuc.where((i) => gecerliKeyler.contains(i.kategori)).toList();
      } else {
        sonuc = sonuc.where((i) => i.kategori == _seciliAnaKey).toList();
      }
    }
    if (_aramaMetni.isNotEmpty) {
      final q = _aramaMetni.toLowerCase();
      sonuc = sonuc.where((i) =>
          i.urun.toLowerCase().contains(q) ||
          i.nereden.toLowerCase().contains(q) ||
          i.nereye.toLowerCase().contains(q) ||
          i.notlar.toLowerCase().contains(q)).toList();
    }
    return sonuc;
  }

  void _filtreAc() {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 250),
      pageBuilder: (_, _, _) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, _, _) {
        final slide = Tween<Offset>(
          begin: const Offset(1, 0), end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic));
        return SlideTransition(
          position: slide,
          child: Material(
            color: Colors.transparent,
            child: FiltreEkrani(
              seciliAnaKey: _seciliAnaKey,
              seciliAltKey: _seciliAltKey,
              onSecildi: (anaKey, altKey) {
                setState(() { _seciliAnaKey = anaKey; _seciliAltKey = altKey; });
                Navigator.of(ctx).pop();
              },
              onTemizle: () {
                setState(() { _seciliAnaKey = null; _seciliAltKey = null; });
                Navigator.of(ctx).pop();
              },
            ),
          ),
        );
      },
    );
  }

  void _siralamaSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 36, height: 4,
                  decoration: BoxDecoration(color: AppColors.divider,
                      borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 16),
              Text('Sırala', style: GoogleFonts.dmSans(
                  fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              ...SiralamaTipi.values.map((tip) {
                final secili = _siralama == tip;
                return InkWell(
                  onTap: () { setState(() => _siralama = tip); Navigator.pop(ctx); },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(children: [
                      Expanded(child: Text(tip.label, style: GoogleFonts.dmSans(
                          fontSize: 15,
                          color: secili ? AppColors.red : AppColors.textPrimary,
                          fontWeight: secili ? FontWeight.w600 : FontWeight.w400))),
                      if (secili) const Icon(Icons.check, color: AppColors.red, size: 20),
                    ]),
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  void _kategoriSec(String anaKey) {
    setState(() {
      if (_seciliAnaKey == anaKey) { _seciliAnaKey = null; _seciliAltKey = null; }
      else { _seciliAnaKey = anaKey; _seciliAltKey = null; }
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final state      = ref.watch(istekIlanlarProvider);
    final mod        = ref.watch(gridTercihiProvider);
    final ilanlar    = _sirala(_filtrele(state.filtrelenmis));
    final filtrAktif = _seciliAnaKey != null;
    final statusH    = MediaQuery.of(context).padding.top;
    final isSwipe    = mod == GoruntulemeModeli.swipe;

    Widget ilanWidget;
    if (isSwipe) {
      // ── Swipe modu ────────────────────────────────────────────────────
      ilanWidget = SwipeGorunumu(
        ilanlar: ilanlar,
        onDahaFazla: () {
          if (!ref.read(istekIlanlarProvider).yukleniyor) {
            ref.read(istekIlanlarProvider.notifier).dahaFazlaYukle();
          }
        },
      );
    } else if (state.yukleniyor && ilanlar.isEmpty) {
      ilanWidget = SliverToBoxAdapter(
          child: ShimmerGrid(kolonSayisi: mod.kolonSayisi));
    } else if (ilanlar.isEmpty) {
      ilanWidget = SliverToBoxAdapter(
        child: filtrAktif || _aramaMetni.isNotEmpty
            ? FiltreBosBekran(onTemizle: () => setState(() {
                _seciliAnaKey = null; _seciliAltKey = null;
                _aramaMetni = ''; _aramaCtrl.clear();
              }))
            : BosEkran(onYenile: () =>
                ref.read(istekIlanlarProvider.notifier).yenile()),
      );
    } else {
      ilanWidget = SliverMasonryGrid.count(
        crossAxisCount: mod.kolonSayisi,
        mainAxisSpacing: 6,
        crossAxisSpacing: 6,
        childCount: ilanlar.length,
        itemBuilder: (context, index) => RepaintBoundary(
          key: ValueKey(ilanlar[index].id),
          child: IlanKarti(
            ilan: ilanlar[index],
            resimYukseklikleri: _kResimYukseklikleri,
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.surface,
      body: Column(
        children: [

          // ── Status bar ─────────────────────────────────────────────────
          Container(height: statusH, color: Colors.white),

          // ── Header — arama + mod seçici ────────────────────────────────
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutCubic,
            height: _aramaGizli || isSwipe ? 0 : null,
            color: Colors.white,
            clipBehavior: Clip.antiAlias,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Arama satırı
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
                  child: Row(
                    children: [
                      // Arama kutusu
                      Expanded(
                        child: Container(
                          height: 42,
                          decoration: BoxDecoration(
                            color: const Color(0xFFF5F5F5),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                                color: const Color(0xFFE8E8E8), width: 1.5),
                          ),
                          child: Row(
                            children: [
                              const SizedBox(width: 12),
                              const Icon(Icons.search_rounded,
                                  size: 16, color: Color(0xFFBBBBBB)),
                              Container(
                                width: 1,
                                height: 16,
                                margin: const EdgeInsets.symmetric(horizontal: 8),
                                color: const Color(0xFFDDDDDD),
                              ),
                              Expanded(
                                child: TextField(
                                  controller: _aramaCtrl,
                                  onChanged: (v) =>
                                      setState(() => _aramaMetni = v),
                                  style: GoogleFonts.dmSans(
                                      fontSize: 13,
                                      color: AppColors.textPrimary),
                                  decoration: InputDecoration(
                                    hintText: 'Ne getirmemizi istersin?',
                                    hintStyle: GoogleFonts.dmSans(
                                        color: AppColors.textHint,
                                        fontSize: 13),
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                ),
                              ),
                              if (_aramaMetni.isNotEmpty) ...[
                                GestureDetector(
                                  onTap: () {
                                    _aramaCtrl.clear();
                                    setState(() => _aramaMetni = '');
                                  },
                                  child: const Icon(Icons.close_rounded,
                                      size: 14,
                                      color: AppColors.textSecondary),
                                ),
                                const SizedBox(width: 4),
                              ],
                              // Sıralama
                              _ToolBtn(
                                onTap: _siralamaSheet,
                                aktif: _siralama != SiralamaTipi.enYeni,
                                child: const Icon(Icons.sort_rounded, size: 16),
                              ),
                              const SizedBox(width: 4),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Filtre butonu — kırmızı
                      GestureDetector(
                        onTap: _filtreAc,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: filtrAktif
                                ? AppColors.red
                                : AppColors.red,
                            borderRadius: BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.red.withValues(alpha: 0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              const Icon(Icons.tune_rounded,
                                  color: Colors.white, size: 18),
                              if (filtrAktif)
                                Positioned(
                                  top: 7,
                                  right: 7,
                                  child: Container(
                                    width: 7,
                                    height: 7,
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      const BildirimCaniWidget(),
                    ],
                  ),
                ),

                // Neden İSTE barı
                const _NedenIsteBar(),
              ],
            ),
          ),

          // ── Kategori + Mod seçici ──────────────────────────────────────
          if (!isSwipe)
            Container(
              color: Colors.white,
              child: Row(
                children: [
                  // Kategori listesi
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: ListView.builder(
                        controller: _kategoriScrollCtrl,
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        itemCount: kKategoriAgaci.length,
                        itemBuilder: (context, i) {
                          final kat    = kKategoriAgaci[i];
                          final secili = _seciliAnaKey == kat.key;
                          return GestureDetector(
                            onTap: () => _kategoriSec(kat.key),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              margin: const EdgeInsets.only(right: 6),
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 12),
                              decoration: BoxDecoration(
                                color: secili
                                    ? AppColors.red
                                    : AppColors.surface,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              alignment: Alignment.center,
                              child: Text(kat.ad,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: secili
                                        ? Colors.white
                                        : AppColors.textPrimary,
                                  )),
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  // Mod butonları — 3 ayrı ikon
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: Row(
                      children: [
                        _ModButon(
                          ikon: Icons.grid_view_rounded,
                          aktif: mod == GoruntulemeModeli.iki,
                          onTap: () => ref
                              .read(gridTercihiProvider.notifier)
                              .modSec(GoruntulemeModeli.iki),
                        ),
                        const SizedBox(width: 4),
                        _ModButon(
                          ikon: Icons.view_module_rounded,
                          aktif: mod == GoruntulemeModeli.uc,
                          onTap: () => ref
                              .read(gridTercihiProvider.notifier)
                              .modSec(GoruntulemeModeli.uc),
                        ),
                        const SizedBox(width: 4),
                        _ModButon(
                          ikon: Icons.swipe_rounded,
                          aktif: mod == GoruntulemeModeli.swipe,
                          onTap: () => ref
                              .read(gridTercihiProvider.notifier)
                              .modSec(GoruntulemeModeli.swipe),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          // Swipe modunda da kategori + mod butonları göster
          if (isSwipe)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Swipe modu — gezinmek için kaydır',
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                  _ModButon(
                    ikon: Icons.grid_view_rounded,
                    aktif: false,
                    onTap: () => ref
                        .read(gridTercihiProvider.notifier)
                        .modSec(GoruntulemeModeli.iki),
                  ),
                  const SizedBox(width: 4),
                  _ModButon(
                    ikon: Icons.view_module_rounded,
                    aktif: false,
                    onTap: () => ref
                        .read(gridTercihiProvider.notifier)
                        .modSec(GoruntulemeModeli.uc),
                  ),
                  const SizedBox(width: 4),
                  _ModButon(
                    ikon: Icons.swipe_rounded,
                    aktif: true,
                    onTap: () {},
                  ),
                ],
              ),
            ),

          // Aktif filtre badge
          if (filtrAktif && !isSwipe)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
              child: Row(children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.red.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(_filtreBadgeMetni,
                        style: GoogleFonts.dmSans(
                            fontSize: 12,
                            color: AppColors.red,
                            fontWeight: FontWeight.w500)),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => setState(() {
                        _seciliAnaKey = null;
                        _seciliAltKey = null;
                      }),
                      child: const Icon(Icons.close_rounded,
                          size: 13, color: AppColors.red),
                    ),
                  ]),
                ),
              ]),
            ),

          Container(height: 0.5, color: AppColors.divider),

          // ── İçerik ─────────────────────────────────────────────────────
          Expanded(
            child: isSwipe
                ? ilanWidget
                : RefreshIndicator(
                    color: AppColors.red,
                    onRefresh: () =>
                        ref.read(istekIlanlarProvider.notifier).yenile(),
                    child: CustomScrollView(
                      controller: _scrollController,
                      physics: const AlwaysScrollableScrollPhysics(),
                      slivers: [
                        SliverPadding(
                          padding: const EdgeInsets.all(6),
                          sliver: ilanWidget,
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: isSwipe
          ? null // Swipe modunda FAB gizli — alt butonlar yeterli
          : FloatingActionButton.extended(
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          const IlanFormScreen(tip: IlanTip.istek))),
              backgroundColor: AppColors.red,
              icon: const Icon(Icons.add, color: Colors.white),
              label: Text('İlan Ver',
                  style: GoogleFonts.dmSans(
                      color: Colors.white, fontWeight: FontWeight.w600)),
            ),
    );
  }
}

// ── Mod butonu ───────────────────────────────────────────────────────────────

class _ModButon extends StatelessWidget {
  final IconData ikon;
  final bool aktif;
  final VoidCallback onTap;

  const _ModButon({
    required this.ikon,
    required this.aktif,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: aktif ? AppColors.red : const Color(0xFFF5F5F5),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: aktif ? AppColors.red : const Color(0xFFE8E8E8),
          ),
        ),
        child: Icon(
          ikon,
          size: 14,
          color: aktif ? Colors.white : const Color(0xFF9E9E9E),
        ),
      ),
    );
  }
}

// ── Araç butonu ───────────────────────────────────────────────────────────────

class _ToolBtn extends StatelessWidget {
  final VoidCallback onTap;
  final Widget child;
  final bool aktif;
  const _ToolBtn({required this.onTap, required this.child, this.aktif = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        margin: const EdgeInsets.symmetric(horizontal: 1),
        decoration: BoxDecoration(
          color: aktif
              ? AppColors.red.withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: IconTheme(
          data: IconThemeData(
              color: aktif ? AppColors.red : AppColors.textSecondary,
              size: 16),
          child: child,
        ),
      ),
    );
  }
}

// ── Neden İSTE — kayan yazı ───────────────────────────────────────────────────

class _NedenIsteBar extends StatefulWidget {
  const _NedenIsteBar();

  @override
  State<_NedenIsteBar> createState() => _NedenIsteBarState();
}

class _NedenIsteBarState extends State<_NedenIsteBar>
    with SingleTickerProviderStateMixin {
  late final ScrollController _ctrl;
  late final Ticker _ticker;
  double _offset = 0;
  double _contentWidth = 0;

  static const _hiz = 0.6;
  static const _maddeler = [
    'Güvenli alışveriş',
    'Onaylı taşıyıcılar',
    'Uygun fiyat',
    'Kolay iade',
    'Hızlı teslimat',
  ];

  @override
  void initState() {
    super.initState();
    _ctrl = ScrollController();
    // reduce-motion kontrolü
    final reduceMotion = SchedulerBinding
        .instance.platformDispatcher.accessibilityFeatures.reduceMotion;
    _ticker = createTicker(_onTick);
    if (!reduceMotion) _ticker.start();
  }

  void _onTick(Duration elapsed) {
    if (!_ctrl.hasClients) return;
    if (_contentWidth == 0) return;
    _offset += _hiz;
    if (_offset >= _contentWidth) _offset = 0;
    _ctrl.jumpTo(_offset);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFC8E6C9),
      height: 28,
      child: LayoutBuilder(builder: (context, constraints) {
        _contentWidth =
            (_maddeler.length * 120.0 + _maddeler.length * 16.0);
        return SingleChildScrollView(
          controller: _ctrl,
          scrollDirection: Axis.horizontal,
          physics: const NeverScrollableScrollPhysics(),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              for (var r = 0; r < 3; r++) ...[
                for (final m in _maddeler) ...[
                  const SizedBox(width: 16),
                  _NedenItem(metin: m),
                  _NedenAyrac(),
                ],
              ],
            ],
          ),
        );
      }),
    );
  }
}

class _NedenItem extends StatelessWidget {
  final String metin;
  const _NedenItem({required this.metin});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.check_circle_rounded,
            size: 12, color: Color(0xFF388E3C)),
        const SizedBox(width: 4),
        Text(metin,
            style: GoogleFonts.dmSans(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF1B5E20))),
      ],
    );
  }
}

class _NedenAyrac extends StatelessWidget {
  const _NedenAyrac();
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 3, height: 3,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      decoration: const BoxDecoration(
          color: Color(0xFF4CAF50), shape: BoxShape.circle),
    );
  }
}