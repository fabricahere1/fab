// lib/features/degerlendirme/data/degerlendirme_repository.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'degerlendirme_repository.g.dart';

@riverpod
DegerlendirmeRepository degerlendirmeRepository(Ref ref) {
  return DegerlendirmeRepository();
}

class DegerlendirmeRepository {
  final _db = FirebaseFirestore.instance;

  Future<void> degerlendirmeGonder({
    required String sohbetId,
    required String degerlendireninId,
    required String hedefKullaniciId,
    required double puan,
    required String yorum,
  }) async {
    await _db.runTransaction((tx) async {
      final userRef = _db.collection('kullanicilar').doc(hedefKullaniciId);
      final degRef  = _db.collection('degerlendirmeler').doc();
      final snap    = await tx.get(userRef);

      tx.set(degRef, {
        'sohbetId':          sohbetId,
        'degerlendireninId': degerlendireninId,
        'hedefKullaniciId':  hedefKullaniciId,
        'puan':              puan,
        'yorum':             yorum,
        'tarih':             FieldValue.serverTimestamp(),
      });

      if (snap.exists) {
        final d = snap.data() as Map<String, dynamic>;
        final mevcutPuan = (d['ortalamaPuan']        as num?)?.toDouble() ?? 0.0;
        final mevcutSayi = (d['degerlendirmeSayisi'] as num?)?.toInt()    ?? 0;
        final yeniSayi   = mevcutSayi + 1;
        final yeniPuan   = ((mevcutPuan * mevcutSayi) + puan) / yeniSayi;
        tx.update(userRef, {
          'ortalamaPuan':        yeniPuan,
          'degerlendirmeSayisi': yeniSayi,
        });
      }
    });
  }

  Future<void> sohbetDegerlendirmeyiIsaretle({
    required String sohbetId,
    required String kullaniciId,
  }) async {
    await _db.collection('sohbetler').doc(sohbetId).update({
      'degerlendirmeYapildi_$kullaniciId': true,
    });
  }

  Future<bool> zatenDegerlendirdimMi({
    required String sohbetId,
    required String kullaniciId,
  }) async {
    final snap = await _db.collection('sohbetler').doc(sohbetId).get();
    if (!snap.exists) return false;
    final d = snap.data() as Map<String, dynamic>;
    return d['degerlendirmeYapildi_$kullaniciId'] == true;
  }
}
