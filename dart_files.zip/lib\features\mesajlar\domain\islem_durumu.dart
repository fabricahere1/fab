// lib/features/mesajlar/domain/islem_durumu.dart

enum IslemDurumu {
  iletisimBasladi,
  anlasildi,
  yolaCikti,
  teslimEdildi,
  teslimAlindi,
}

extension IslemDurumuX on IslemDurumu {
  String get etiket {
    switch (this) {
      case IslemDurumu.iletisimBasladi: return 'İletişime Geçildi';
      case IslemDurumu.anlasildi:       return 'Anlaşıldı';
      case IslemDurumu.yolaCikti:       return 'Yola Çıktı';
      case IslemDurumu.teslimEdildi:    return 'Teslim Edildi';
      case IslemDurumu.teslimAlindi:    return 'Teslim Alındı';
    }
  }

  String get firestoreKey {
    switch (this) {
      case IslemDurumu.iletisimBasladi: return 'iletisimBasladi';
      case IslemDurumu.anlasildi:       return 'anlasildi';
      case IslemDurumu.yolaCikti:       return 'yolaCikti';
      case IslemDurumu.teslimEdildi:    return 'teslimEdildi';
      case IslemDurumu.teslimAlindi:    return 'teslimAlindi';
    }
  }

  IslemDurumu? get sonraki {
    final idx = IslemDurumu.values.indexOf(this);
    if (idx < IslemDurumu.values.length - 1) {
      return IslemDurumu.values[idx + 1];
    }
    return null;
  }

  // true = taşıyıcı, false = alıcı, null = otomatik
  bool? get tasiyiciMi {
    switch (this) {
      case IslemDurumu.iletisimBasladi: return null;
      case IslemDurumu.anlasildi:       return null;
      case IslemDurumu.yolaCikti:       return true;
      case IslemDurumu.teslimEdildi:    return true;
      case IslemDurumu.teslimAlindi:    return false;
    }
  }
}
