import 'g_colors.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'sohbet_screen.dart';
import 'degerlendirme_screen.dart';
import '../auth_gate.dart';

class FavorilerPage extends StatelessWidget {
  const FavorilerPage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: GColors.surface,
      appBar: AppBar(
        backgroundColor: GColors.white,
        elevation: 0,
        scrolledUnderElevation: 1,
        shadowColor: GColors.divider,
        title: Text('Favoriler',
            style: GoogleFonts.dmSans(
                color: GColors.textPrimary,
                fontWeight: FontWeight.w600,
                fontSize: 18)),
      ),
      body: user == null
          ? GirisGerekli(
              icon: Icons.bookmark_outline,
              mesaj: 'Favorileri görmek için giriş yapın.',
              onGirisYap: () => loginGerekli(context),
            )
          : StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('favoriler')
                  .where('kullaniciId', isEqualTo: user.uid)
                  .orderBy('eklemeTarihi', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator(
                          color: GColors.red, strokeWidth: 2));
                }
                final docs = snapshot.data?.docs ?? [];
                if (docs.isEmpty) {
                  return const BosEkran(
                    icon: Icons.bookmark_outline,
                    mesaj: 'Henüz favori eklemediniz.',
                    altMesaj: 'İlanlarda 🔖 simgesine tıklayarak ekleyin.',
                    renk: GColors.blue,
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data() as Map<String, dynamic>;
                    final tip = data['tip'] ?? 'istek';
                    final isim = data['kullaniciAd'] ?? 'Kullanıcı';
                    final ilanId = data['ilanId'] as String? ?? '';

                    return GestureDetector(
                      onTap: () {
                        FirebaseFirestore.instance
                            .collection('ilanlar')
                            .doc(data['ilanId'])
                            .get()
                            .then((ilanDoc) {
                          if (!context.mounted) return;
                          if (ilanDoc.exists) {
                            _ilanDetayGoster(
                              context,
                              ilanDoc.id,
                              ilanDoc.data() as Map<String, dynamic>,
                              tip: tip,
                              favoriDocId: doc.id,
                            );
                          } else {
                            // YENİ: ilan silinmiş → "kaldırıldı" sheet'i göster
                            _silinmisIlanGoster(context, doc.id, data);
                          }
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                          color: GColors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: GColors.divider),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              FutureBuilder<DocumentSnapshot>(
                                future: FirebaseFirestore.instance
                                    .collection('ilanlar')
                                    .doc(ilanId)
                                    .get(),
                                builder: (ctx, snap) {
                                  final url = (snap.hasData && snap.data!.exists)
                                      ? ((snap.data!.data() as Map<String, dynamic>)['resimUrl'] as String? ?? '')
                                      : '';
                                  return ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: url.isNotEmpty
                                        ? CachedNetworkImage(
                                            imageUrl: url,
                                            width: 48,
                                            height: 48,
                                            fit: BoxFit.cover,
                                            placeholder: (_, __) => _avatarKutu(isim, 48),
                                            errorWidget: (_, __, ___) => _avatarKutu(isim, 48),
                                          )
                                        : _avatarKutu(isim, 48),
                                  );
                                },
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(isim,
                                              overflow: TextOverflow.ellipsis,
                                              style: GoogleFonts.dmSans(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14,
                                                  color: GColors.textPrimary)),
                                        ),
                                        GChip(
                                          label: tip == 'tasiyici'
                                              ? '✈️ Gelen'
                                              : '🛍️ İstek',
                                          icon: tip == 'tasiyici'
                                              ? Icons.flight
                                              : Icons.shopping_bag_outlined,
                                          bgColor: GColors.chipBg,
                                          textColor: GColors.textSecondary,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const Icon(Icons.location_on_outlined,
                                            size: 12,
                                            color: GColors.textSecondary),
                                        const SizedBox(width: 3),
                                        Expanded(
                                          child: Text(
                                            '${data['nereden'] ?? ''} → ${data['nereye'] ?? ''}',
                                            overflow: TextOverflow.ellipsis,
                                            style: GoogleFonts.dmSans(
                                                fontSize: 12,
                                                color: GColors.textSecondary),
                                          ),
                                        ),
                                      ],
                                    ),
                                    if (tip == 'istek' &&
                                        data['urun'] != null &&
                                        data['urun'] != '') ...[
                                      const SizedBox(height: 3),
                                      Text(data['urun'],
                                          overflow: TextOverflow.ellipsis,
                                          style: GoogleFonts.dmSans(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                              color: GColors.textPrimary)),
                                    ],
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              GestureDetector(
                                onTap: () async {
                                  final onay = await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12)),
                                      title: Text('Favoriden Kaldır',
                                          style: GoogleFonts.dmSans(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600)),
                                      content: Text(
                                          'Bu ilanı favorilerden kaldırmak istiyor musunuz?',
                                          style: GoogleFonts.dmSans(
                                              fontSize: 14,
                                              color: GColors.textSecondary)),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, false),
                                          child: Text('İptal',
                                              style: GoogleFonts.dmSans(
                                                  color:
                                                      GColors.textSecondary)),
                                        ),
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(ctx, true),
                                          child: Text('Kaldır',
                                              style: GoogleFonts.dmSans(
                                                  color: GColors.red,
                                                  fontWeight:
                                                      FontWeight.w700)),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (onay == true) {
                                    await FirebaseFirestore.instance
                                        .collection('favoriler')
                                        .doc(doc.id)
                                        .delete();
                                  }
                                },
                                child: const Icon(Icons.bookmark,
                                    color: GColors.yellow, size: 22),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

// ── Silinmiş ilan sheet'i ─────────────────────────────────

Widget _avatarKutu(String isim, double size) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: avatarRenk(isim),
      borderRadius: BorderRadius.circular(8),
    ),
    child: Center(
      child: Text(
        isim[0].toUpperCase(),
        style: GoogleFonts.dmSans(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: size * 0.33),
      ),
    ),
  );
}

void _silinmisIlanGoster(
    BuildContext context, String favoriDocId, Map<String, dynamic> data) {
  final tip = data['tip'] ?? 'istek';
  final isim = data['kullaniciAd'] ?? 'Kullanıcı';
  final urun = data['urun'] ?? '';
  final nereden = data['nereden'] ?? '';
  final nereye = data['nereye'] ?? '';

  showModalBottomSheet(
    context: context,
    backgroundColor: GColors.white,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (context) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                  color: GColors.divider,
                  borderRadius: BorderRadius.circular(2)),
            ),
          ),
          const SizedBox(height: 28),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: const Color(0xFFF5F5F5),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Center(
              child: Text(
                tip == 'tasiyici' ? '✈️' : '🛍️',
                style: const TextStyle(fontSize: 30),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Bu ilan kaldırıldı',
            style: GoogleFonts.dmSans(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: GColors.textPrimary),
          ),
          const SizedBox(height: 6),
          Text(
            urun.isNotEmpty ? urun : '$nereden → $nereye',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(
                fontSize: 13, color: GColors.textSecondary),
          ),
          const SizedBox(height: 4),
          Text(
            isim,
            style: GoogleFonts.dmSans(
                fontSize: 12, color: GColors.textHint),
          ),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('favoriler')
                    .doc(favoriDocId)
                    .delete();
                if (context.mounted) Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: GColors.red,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
              child: Text('Favorilerden Kaldır',
                  style: GoogleFonts.dmSans(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14)),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Kapat',
                style: GoogleFonts.dmSans(
                    color: GColors.textSecondary, fontSize: 14)),
          ),
        ],
      ),
    ),
  );
}

// ── İlan Detay Sheet ──────────────────────────────────────

void _ilanDetayGoster(
  BuildContext context,
  String docId,
  Map<String, dynamic> data, {
  required String tip,
  required String favoriDocId,
}) {
  final resimUrl = data['resimUrl'] as String?;
  final resimVar = resimUrl != null && resimUrl.isNotEmpty;
  final isim = data['kullaniciAd'] ?? 'Kullanıcı';
  final kullaniciId = data['kullaniciId'] ?? '';
  final urun = data['urun'] ?? '';
  final nereden = data['nereden'] ?? '';
  final nereye = data['nereye'] ?? '';
  final ucret = data['ucret'] ?? '';
  final notlar = data['notlar'] ?? '';
  final currentUid = FirebaseAuth.instance.currentUser?.uid;
  final benimIlanim = currentUid != null && currentUid == kullaniciId;

  showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF111111),
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (context) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.65,
      maxChildSize: 0.95,
      minChildSize: 0.4,
      builder: (context, scrollController) => Column(
        children: [
          Expanded(child: SingleChildScrollView(
        controller: scrollController,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 12, bottom: 8),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                    color: const Color(0xFF333333),
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            if (resimVar)
              CachedNetworkImage(
                imageUrl: resimUrl,
                width: double.infinity,
                height: 240,
                fit: BoxFit.cover,
                placeholder: (_, __) =>
                    Container(height: 240, color: const Color(0xFF1A1A1A)),
                errorWidget: (_, __, ___) =>
                    Container(height: 240, color: const Color(0xFF1A1A1A)),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      tip == 'tasiyici' ? '✈️  TAŞIYICI' : '🛍️  İSTEK',
                      style: GoogleFonts.dmSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF666666),
                          letterSpacing: 2),
                    ),
                  ),
                  const SizedBox(height: 14),
                  if (urun.isNotEmpty)
                    Text(urun,
                        style: GoogleFonts.dmSans(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: Colors.white)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Text(nereden.toUpperCase(),
                          style: GoogleFonts.dmSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF666666),
                              letterSpacing: 1)),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Icon(Icons.arrow_forward,
                            color: GColors.red, size: 14),
                      ),
                      Text(nereye.toUpperCase(),
                          style: GoogleFonts.dmSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: GColors.red,
                              letterSpacing: 1)),
                    ],
                  ),
                  if (ucret.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text('₺$ucret',
                        style: GoogleFonts.dmSans(
                            fontSize: 28,
                            fontWeight: FontWeight.w800,
                            color: GColors.red)),
                  ],
                  // YENİ: ilan giriliş tarihi
                  Builder(builder: (context) {
                    final t = data['olusturmaTarihi'];
                    if (t == null) return const SizedBox.shrink();
                    final dt = (t as Timestamp).toDate();
                    final str =
                        '${dt.day}.${dt.month}.${dt.year}';
                    return Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Row(
                        children: [
                          const Icon(Icons.access_time,
                              size: 13, color: Color(0xFF666666)),
                          const SizedBox(width: 5),
                          Text('$str tarihinde eklendi',
                              style: GoogleFonts.dmSans(
                                  fontSize: 12,
                                  color: const Color(0xFF666666))),
                        ],
                      ),
                    );
                  }),
                  if (notlar.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(notlar,
                        style: GoogleFonts.dmSans(
                            fontSize: 14,
                            color: const Color(0xFF888888),
                            height: 1.5)),
                  ],
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      _profilPopupGoster(context,
                          kullaniciId: kullaniciId, isim: isim);
                    },
                    child: Row(
                      children: [
                        avatarWidget(isim: isim, radius: 18, fontSize: 13),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(isim,
                                  style: GoogleFonts.dmSans(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: const Color(0xFF888888))),
                              Text('Profile git →',
                                  style: GoogleFonts.dmSans(
                                      fontSize: 11, color: GColors.red)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right,
                            color: GColors.red, size: 16),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      )),
          if (!benimIlanim)
            Padding(
              padding: EdgeInsets.fromLTRB(
                  20, 8, 20, MediaQuery.of(context).padding.bottom + 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () async {
                          await FirebaseFirestore.instance
                              .collection('favoriler')
                              .doc(favoriDocId)
                              .delete();
                          if (context.mounted) Navigator.pop(context);
                        },
                        child: Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A1A),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFF2A2A2A)),
                          ),
                          child: const Icon(Icons.bookmark,
                              color: GColors.yellow, size: 22),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            final user = FirebaseAuth.instance.currentUser;
                            Navigator.pop(context);
                            if (user == null) {
                              loginGerekli(context);
                              return;
                            }
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SohbetScreen(
                                  karsiKullaniciId: kullaniciId,
                                  karsiKullaniciAd: isim,
                                  ilanId: docId,
                                  ilanBaslik: urun.isNotEmpty
                                      ? urun
                                      : '$nereden → $nereye',
                                ),
                              ),
                            );
                          },
                          child: Container(
                            height: 52,
                            decoration: BoxDecoration(
                              color: GColors.red,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(
                                'İletişime Geç',
                                style: GoogleFonts.dmSans(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Center(
                    child: TextButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        sikayetGonder(context,
                            hedefId: kullaniciId,
                            hedefAd: isim,
                            ilanId: docId);
                      },
                      icon: const Icon(Icons.flag_outlined,
                          color: GColors.red, size: 15),
                      label: Text('Şikayet Et',
                          style: GoogleFonts.dmSans(
                              color: GColors.red, fontSize: 13)),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    ),
  );
}
// ── Profil Popup ──────────────────────────────────────────

void _profilPopupGoster(
  BuildContext context, {
  required String kullaniciId,
  required String isim,
}) {
  showModalBottomSheet(
    context: context,
    backgroundColor: GColors.white,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (context) => FutureBuilder<QuerySnapshot>(
      future: FirebaseFirestore.instance
          .collection('degerlendirmeler')
          .where('hedefId', isEqualTo: kullaniciId)
          .get(),
      builder: (context, degSnap) {
        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('kullanicilar')
              .doc(kullaniciId)
              .get(),
          builder: (context, profilSnap) {
            final profilData = profilSnap.data?.data() as Map<String, dynamic>?;
            final sehir = profilData?['sehir']?.toString().trim() ?? '';
            final fotoUrl = profilData?['fotoUrl']?.toString() ?? '';
            final degerlendirmeler = degSnap.data?.docs ?? [];
            final ortalama = degerlendirmeler.isEmpty
                ? 0.0
                : degerlendirmeler
                        .map((d) => (d.data() as Map)['puan'] as num? ?? 0)
                        .reduce((a, b) => a + b) /
                    degerlendirmeler.length;

            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.6,
              maxChildSize: 0.9,
              minChildSize: 0.4,
              builder: (context, scrollController) => SingleChildScrollView(
                controller: scrollController,
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
                child: Column(
                  children: [
                    Center(
                      child: Container(
                        margin: const EdgeInsets.only(top: 12, bottom: 20),
                        width: 36, height: 4,
                        decoration: BoxDecoration(
                            color: GColors.divider,
                            borderRadius: BorderRadius.circular(2)),
                      ),
                    ),
                    avatarWidget(
                        isim: isim,
                        fotoUrl: fotoUrl.isEmpty ? null : fotoUrl,
                        radius: 36, fontSize: 24),
                    const SizedBox(height: 12),
                    Text(isim,
                        style: GoogleFonts.dmSans(
                            fontSize: 20, fontWeight: FontWeight.w800,
                            color: GColors.textPrimary)),
                    if (sehir.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(sehir,
                          style: GoogleFonts.dmSans(
                              fontSize: 14, color: GColors.textSecondary)),
                    ],
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.star, color: GColors.yellow, size: 18),
                        const SizedBox(width: 4),
                        Text(
                          degerlendirmeler.isEmpty
                              ? 'Henüz değerlendirme yok'
                              : '${ortalama.toStringAsFixed(1)} (${degerlendirmeler.length} değerlendirme)',
                          style: GoogleFonts.dmSans(
                              fontSize: 13, color: GColors.textSecondary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Divider(color: GColors.divider),
                    const SizedBox(height: 12),
                    if (degerlendirmeler.isNotEmpty) ...[
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text('Değerlendirmeler',
                            style: GoogleFonts.dmSans(
                                fontSize: 14, fontWeight: FontWeight.w700,
                                color: GColors.textPrimary)),
                      ),
                      const SizedBox(height: 12),
                      ...degerlendirmeler.take(5).map((d) {
                        final dData = d.data() as Map<String, dynamic>;
                        final ad = dData['degerlendiriciAd'] ?? 'Kullanıcı';
                        final yorum = dData['yorum'] ?? '';
                        final puan = (dData['puan'] as num?)?.toInt() ?? 0;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              avatarWidget(isim: ad, radius: 18, fontSize: 12),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(children: [
                                      Text(ad, style: GoogleFonts.dmSans(
                                          fontSize: 13, fontWeight: FontWeight.w600)),
                                      const SizedBox(width: 8),
                                      ...List.generate(5, (i) => Icon(
                                        i < puan ? Icons.star : Icons.star_outline,
                                        size: 12, color: GColors.yellow,
                                      )),
                                    ]),
                                    if (yorum.isNotEmpty)
                                      Text(yorum, style: GoogleFonts.dmSans(
                                          fontSize: 12, color: GColors.textSecondary)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                    ] else
                      Text('Henüz değerlendirme yok.',
                          style: GoogleFonts.dmSans(
                              fontSize: 13, color: GColors.textSecondary)),
                  ],
                ),
              ),
            );
          },
        );
      },
    ),
  );
}